﻿using System;
using System.IO;
using System.IO.Ports;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private SerialPort _serialPort;
        private StreamWriter _logWriter;

        public Form1()
        {
            InitializeComponent();
            _serialPort = new SerialPort();
            _serialPort.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);
            this.FormClosing += new FormClosingEventHandler(Form1_FormClosing);
        }

        private void LogError(string message)
        {
            string logDirectory = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "logs");
            Directory.CreateDirectory(logDirectory);
            string logFilePath = Path.Combine(logDirectory, "error_log.txt");
            File.AppendAllText(logFilePath, $"{DateTime.Now}: {message}{Environment.NewLine}");
        }



        private void button_Connect_Click(object sender, EventArgs e)
        {
            try
            {
                if (_serialPort.IsOpen)
                {
                    _serialPort.Close();
                    _logWriter?.Close();
                    button_Connect.Text = "Connect";
                    MessageBox.Show("Port closed successfully!");
                }
                else
                {
                    // Validate COM port name
                    if (string.IsNullOrWhiteSpace(textBox_SerialPort.Text))
                    {
                        MessageBox.Show("Please enter a valid COM port name.");
                        return;
                    }

                    // Validate Baud rate
                    if (!int.TryParse(textBox_BaudRate.Text, out int baudRate))
                    {
                        MessageBox.Show("Please enter a valid Baud rate.");
                        return;
                    }

                    _serialPort.PortName = textBox_SerialPort.Text; // Read COM port from textBox_SerialPort
                    _serialPort.BaudRate = baudRate; // Read Baud rate from textBox_BaudRate
                    _serialPort.Parity = Parity.None;
                    _serialPort.DataBits = 8;
                    _serialPort.StopBits = StopBits.One;
                    _serialPort.Handshake = Handshake.None;
                    _serialPort.Open();

                    // Create log file
                    string logDirectory = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "logs");
                    Directory.CreateDirectory(logDirectory);
                    string logFileName = $"{_serialPort.PortName}_{DateTime.Now:ddMMyyyy_HHmmss}.txt";
                    string logFilePath = Path.Combine(logDirectory, logFileName);
                    _logWriter = new StreamWriter(logFilePath, true);

                    button_Connect.Text = "Disconnect";
                    MessageBox.Show("Port opened successfully!");
                }
            }
            catch (UnauthorizedAccessException)
            {
                MessageBox.Show("Access to the port is denied.");
            }
            catch (ArgumentOutOfRangeException)
            {
                MessageBox.Show("One or more of the properties for this instance are invalid.");
            }
            catch (ArgumentException)
            {
                MessageBox.Show("The port name does not begin with 'COM'.");
            }
            catch (IOException)
            {
                MessageBox.Show("The port is in an invalid state.");
            }
            catch (InvalidOperationException)
            {
                MessageBox.Show("The specified port on the current instance of the SerialPort is already open.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void button_SendData_Click(object sender, EventArgs e)
        {
            try
            {
                if (_serialPort.IsOpen)
                {
                    string[] linesToSend = richTextBox_SendData.Lines;
                    if (linesToSend.Length == 0)
                    {
                        MessageBox.Show("Please enter data to send.");
                        return;
                    }

                    foreach (string line in linesToSend)
                    {
                        if (!string.IsNullOrWhiteSpace(line))
                        {
                            _serialPort.WriteLine(line);
                        }
                    }
                    MessageBox.Show("Data sent successfully!");
                }
                else
                {
                    MessageBox.Show("Port is not open.");
                }
            }
            catch (InvalidOperationException)
            {
                MessageBox.Show("The specified port is not open.");
            }
            catch (TimeoutException)
            {
                MessageBox.Show("The operation did not complete before the time-out period ended.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }


        private void DataReceivedHandler(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                string data = _serialPort.ReadLine();
                this.Invoke(new MethodInvoker(delegate
                {
                    richTextBox_ReceiveData.AppendText(data + Environment.NewLine);
                    richTextBox_ReceiveData.ScrollToCaret();
                    _logWriter?.WriteLine(data);
                }));
            }
            catch (Exception ex)
            {
                LogError(ex.Message);
            }
        }



        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (_serialPort.IsOpen)
            {
                _serialPort.Close();
            }
            _logWriter?.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Any initialization code can go here
        }

        private void button_ClearData_Click(object sender, EventArgs e)
        {
            richTextBox_ReceiveData.Clear();
        }
    }
}
