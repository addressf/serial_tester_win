﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_SerialPort = new System.Windows.Forms.TextBox();
            this.textBox_BaudRate = new System.Windows.Forms.TextBox();
            this.button_Connect = new System.Windows.Forms.Button();
            this.button_SendData = new System.Windows.Forms.Button();
            this.richTextBox_SendData = new System.Windows.Forms.RichTextBox();
            this.richTextBox_ReceiveData = new System.Windows.Forms.RichTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button_ClearData = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "COM Port Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(232, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Baud Rate";
            // 
            // textBox_SerialPort
            // 
            this.textBox_SerialPort.Location = new System.Drawing.Point(102, 2);
            this.textBox_SerialPort.Name = "textBox_SerialPort";
            this.textBox_SerialPort.Size = new System.Drawing.Size(100, 20);
            this.textBox_SerialPort.TabIndex = 2;
            // 
            // textBox_BaudRate
            // 
            this.textBox_BaudRate.Location = new System.Drawing.Point(306, 6);
            this.textBox_BaudRate.Name = "textBox_BaudRate";
            this.textBox_BaudRate.Size = new System.Drawing.Size(100, 20);
            this.textBox_BaudRate.TabIndex = 3;
            // 
            // button_Connect
            // 
            this.button_Connect.Location = new System.Drawing.Point(439, 4);
            this.button_Connect.Name = "button_Connect";
            this.button_Connect.Size = new System.Drawing.Size(75, 23);
            this.button_Connect.TabIndex = 4;
            this.button_Connect.Text = "Connect";
            this.button_Connect.UseVisualStyleBackColor = true;
            this.button_Connect.Click += new System.EventHandler(this.button_Connect_Click);
            // 
            // button_SendData
            // 
            this.button_SendData.Location = new System.Drawing.Point(235, 73);
            this.button_SendData.Name = "button_SendData";
            this.button_SendData.Size = new System.Drawing.Size(75, 23);
            this.button_SendData.TabIndex = 5;
            this.button_SendData.Text = "Send Data";
            this.button_SendData.UseVisualStyleBackColor = true;
            this.button_SendData.Click += new System.EventHandler(this.button_SendData_Click);
            // 
            // richTextBox_SendData
            // 
            this.richTextBox_SendData.Location = new System.Drawing.Point(15, 94);
            this.richTextBox_SendData.Name = "richTextBox_SendData";
            this.richTextBox_SendData.Size = new System.Drawing.Size(377, 255);
            this.richTextBox_SendData.TabIndex = 7;
            this.richTextBox_SendData.Text = "";
            // 
            // richTextBox_ReceiveData
            // 
            this.richTextBox_ReceiveData.Location = new System.Drawing.Point(411, 94);
            this.richTextBox_ReceiveData.Name = "richTextBox_ReceiveData";
            this.richTextBox_ReceiveData.ReadOnly = true;
            this.richTextBox_ReceiveData.Size = new System.Drawing.Size(377, 255);
            this.richTextBox_ReceiveData.TabIndex = 8;
            this.richTextBox_ReceiveData.Text = "";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 78);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(144, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Fill the data to Send in Below";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(408, 78);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(119, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Data Received in Serial";
            // 
            // button_ClearData
            // 
            this.button_ClearData.Location = new System.Drawing.Point(713, 68);
            this.button_ClearData.Name = "button_ClearData";
            this.button_ClearData.Size = new System.Drawing.Size(75, 23);
            this.button_ClearData.TabIndex = 11;
            this.button_ClearData.Text = "Clear Data";
            this.button_ClearData.UseVisualStyleBackColor = true;
            this.button_ClearData.Click += new System.EventHandler(this.button_ClearData_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button_ClearData);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.richTextBox_ReceiveData);
            this.Controls.Add(this.richTextBox_SendData);
            this.Controls.Add(this.button_SendData);
            this.Controls.Add(this.button_Connect);
            this.Controls.Add(this.textBox_BaudRate);
            this.Controls.Add(this.textBox_SerialPort);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Serial Port App";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_SerialPort;
        private System.Windows.Forms.TextBox textBox_BaudRate;
        private System.Windows.Forms.Button button_Connect;
        private System.Windows.Forms.Button button_SendData;
        private System.Windows.Forms.RichTextBox richTextBox_SendData;
        private System.Windows.Forms.RichTextBox richTextBox_ReceiveData;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button_ClearData;
    }
}

